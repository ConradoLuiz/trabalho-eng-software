package br.edu.cefet.trabalho.model;

import java.io.Serializable;

public class Associacao extends Relacionamento implements Serializable{

	private static final long serialVersionUID = 2742509383659435034L;

}
