package br.edu.cefet.trabalho.model;

import java.io.Serializable;

public class Classe extends Elemento implements Serializable{

	private static final long serialVersionUID = 6583240428612326554L;
	
}
