package br.edu.cefet.trabalho.model;

import java.io.Serializable;

public class Interface extends Elemento implements Serializable{

	private static final long serialVersionUID = 2517087991070088794L;

}
