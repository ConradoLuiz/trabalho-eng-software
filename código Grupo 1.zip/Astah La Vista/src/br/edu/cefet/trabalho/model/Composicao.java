package br.edu.cefet.trabalho.model;

import java.io.Serializable;

public class Composicao extends Relacionamento implements Serializable{

	private static final long serialVersionUID = 883667236290363689L;

}
