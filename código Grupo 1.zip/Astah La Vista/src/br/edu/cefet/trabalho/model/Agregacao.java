package br.edu.cefet.trabalho.model;

import java.io.Serializable;

public class Agregacao extends Relacionamento implements Serializable{

	private static final long serialVersionUID = -4250329985281681063L;

}
