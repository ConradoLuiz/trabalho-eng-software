module TestesUnitarios {
	requires org.junit.jupiter.api;
}