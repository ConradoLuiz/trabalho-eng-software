package composite;

public class Metodo extends Elemento{

	@Override
	public String desenha() {
		System.out.println("Desenhou m�todo");
		return "Desenhou m�todo\n";
	}
	
	

}
