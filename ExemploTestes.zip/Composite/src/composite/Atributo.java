package composite;

public class Atributo extends Elemento{

	@Override
	public String desenha() {
		System.out.println("Desenhou atributo");
		return "Desenhou atributo\n";
	}

}
