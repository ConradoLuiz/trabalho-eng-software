package composite;

public abstract class Elemento {
	
	public abstract String desenha();
	

}
