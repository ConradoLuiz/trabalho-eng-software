module Composite {
	requires org.junit.jupiter.api;
}