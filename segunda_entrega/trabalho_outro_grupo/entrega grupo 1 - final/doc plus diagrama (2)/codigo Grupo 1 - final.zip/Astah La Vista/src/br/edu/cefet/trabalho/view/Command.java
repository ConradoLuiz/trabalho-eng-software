package br.edu.cefet.trabalho.view;

public interface Command {
	
	public void execute();
}
