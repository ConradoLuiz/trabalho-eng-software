package br.edu.cefet.trabalho.view;
public class Principal {
	public static void main(String[] args) {
		new MenuView();
	}
}
